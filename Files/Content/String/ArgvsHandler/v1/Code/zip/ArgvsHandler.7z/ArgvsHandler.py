class ArgvsHandler():
    class Argv():
        class String():
            @staticmethod
            def GetInfo(s:str):
                comma = ','
                whitespace = ' '
                newline = '\n'
                semicolon = ':'
                wn = whitespace + newline
                argvList = s.split(comma)
                resultList = list()                
                for argv in argvList :
                    argv = argv.lstrip(wn)
                    argv = argv.split(semicolon)
                    tempList = list()
                    for i in range(0,2,1):
                        temp = ''
                        if i < len(argv):
                            argv[i] = argv[i].strip(wn)
                            temp = argv[i]     
                        else:
                            temp = None
                        tempList.append(temp)
                    resultList.append(tempList)
                return resultList
                
if __name__ == '__main__':
    s = """
    argv1 : list,argv2 : tuple ,argv3 : dict
    """
    r = ArgvsHandler.Argv.String.GetInfo(s)
    print(r)
from REHandler import REHandler
from FuncHandler import FuncHandler
from ClassHandler import ClassHandler

class ContentFinder():
    class Class():
        """
        Intro: 
            Get the content info. 
        Parameter:
            content: a string as content.
        Returned Value:
            A list whose elem is a dict.
            The dict whose keys are classes in content (the next word after class keyword) and 
            whose values are methods in the class (the next word after def keyword).
        Examples:
            Example 1:
                A file content is shown as follows.
                Input:
                    class Response(): def Unknown(): pass \nclass Animal(): def Dog(): pass
                Output:
                    [{'Response': ['Unknown']}, {'Animal': ['Dog']}]
                Explanation:
                    There are two classes Response and Animal.
                    There are one method named Unknown in Response class.
                    There are one method named Dog in Animal class.
        """
        @staticmethod
        def GetInfo(content:str):
            keyword = 'class'
            s = content
            allClass = REHandler.SplitParagraph(s, keyword)
            
            paragraphs = list()
            for class1 in allClass : 
                r = ClassHandler.Class.String.GetInfo(class1)
                paragraphs.append(r)
            allMethod = list()
            for i in range(0,len(paragraphs),1):
                paragraph = paragraphs[i]
                r = FuncHandler.String.GetInfo(paragraph[2])
                elem = [paragraph[0],r]
                allMethod.append(elem)
            return allMethod
if __name__ == '__main__':
    
    print('!'*40)
    s = 'class Response(): def Unknown(): pass \nclass Animal(): def Dog(): pass'
    r = ContentFinder.Class.GetInfo(s)
    print(r)
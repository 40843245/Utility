class ClassHandler():
    class Class():
        class String():
            @staticmethod
            def GetInfo(s : str):
                keyword = "class"
                newline = '\n'
                whitespace = ' '
                leftBracket = '('
                rightBracket = ')'
                semicolon = ':'
                wn = whitespace + newline
        
                s = s.lstrip(wn)
                s = s.lstrip(keyword)
                s = s.lstrip(wn)
                leftBracketIndex = s.index(leftBracket)
                rightBracketIndex = s.index(rightBracket)
                className = s[0:leftBracketIndex]
                inheritance = s[leftBracketIndex+1:rightBracketIndex]
                content = s[rightBracketIndex+1:]
                content = content.lstrip(whitespace)
                semicolonIndex = content.index(semicolon)
                content = content[semicolonIndex+1:]
                content = content.lstrip(wn)
                
                return (className , inheritance , content)
if __name__ == '__main__':
    s = """
    class DemoClass():
        def Func2():
            pass
        
        def Func1():
            return "Method Func1 of DemoClass in demo_2.py file."
    """
    r = ClassHandler.Class.String.GetInfo(s)
    print(r)
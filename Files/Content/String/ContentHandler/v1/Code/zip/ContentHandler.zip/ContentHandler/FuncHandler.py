from ArgvsHandler import ArgvsHandler

class FuncHandler():
    class String():
        @staticmethod
        def GetInfo(s:str):
            definition = "def"
            newline = '\n'
            whitespace = ' '
            leftBracket = '('
            rightBracket = ')'
            semicolon = ':'
            wn = whitespace +newline
            minus = '-'
            gt = '>'
            
            s = s.lstrip(wn)
            s = s.lstrip(definition)
            s = s.lstrip(wn)
            leftBracketIndex = s.index(leftBracket)
            rightBracketIndex = s.index(rightBracket)
            funcName = s[0:leftBracketIndex]
            argvs = s[leftBracketIndex+1:rightBracketIndex]
            content = s[rightBracketIndex+1:]
            content = content.lstrip(whitespace)
            semicolonIndex = content.index(semicolon)
            returnedType= content[0:semicolonIndex]
            returnedType = returnedType.lstrip(whitespace)
            returnedType = returnedType.lstrip(minus)
            returnedType = returnedType.lstrip(gt)
            content = content[semicolonIndex+1:]
            content = content.lstrip(wn)
            
            argvsList = ArgvsHandler.Argv.String.GetInfo(argvs)
            
            return (funcName , argvsList , content)
                   
if __name__ == '__main__':
    s = """
        def Func2(argv1,argv2,)->list:
            pass
    """
    r = FuncHandler.String.GetInfo(s)
    print(r)
            
            
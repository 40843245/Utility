import re

class REHandler():
    @staticmethod
    def WordRest(delim : str , s : str , rests : str ,ends : str ):        
        expr = r'(?<=('+delim+'))('+rests+'+'+ends+'*)'
        m = re.split(expr, s ,flags = re.DOTALL)
        whitespace = ' '
        r = [ elem.removesuffix(whitespace) for elem in m if elem.endswith(delim) == False  ]
        nolast = r[:-1]
        return ( expr, m , r , nolast)
    @staticmethod
    def NextWord(s : str , keyword:str):
        expr = r'(?>('+keyword+'))'+'('+'\s*\w*'+')'
        pattern = re.compile(expr,re.DOTALL)
        m = pattern.search(s,0)
        
        nextword = list()
        while m != None:
            group = m.groups(0)
            span = m.span(0)
            whitespace = ' '
            w = group[-1].strip(whitespace)
            nextword.append(w)
            m = pattern.search(s,span[1])
        return nextword
    
    @staticmethod
    def SplitParagraph(s : str , keyword: str):
        expr = r'(?>('+keyword+'))'+'('+'\s*\w*'+')'
        pattern = re.compile(expr,re.DOTALL)
        indexList = list()
        nextphrase = list()
        currIndex = 0
    
        m = pattern.search(s,0)
        while m != None:
            span = m.span(0)            
            indexList.append(span[0])
            currIndex = span[0]
            m = pattern.search(s,span[1])
            
        for i in range(0,len(indexList),1):
            currIndex = indexList[i]
            if i != len(indexList) - 1  :
                nextIndex = indexList[i+1]
            else:
                nextIndex = len(s)
            w = s[currIndex:nextIndex]
            if w != None and len(w) > 0 :
                w = w.lstrip(keyword)
                nextphrase.append(w)
        return nextphrase
    
    
        
            
if __name__ == '__main__':
    
    print('!'*40)
    
    keyword = 'class'
    s = 'class Response(): def Yes(): pass \n'
    rests = '\w'
    ends = '\s'
    r = REHandler.SplitParagraph(s,keyword)
    print('-'*40)
    print(r)
        
    print('!'*40)    
    
    keyword = 'class'
    s = 'class Response(): def No(): pass \n'
    rests = '\w'
    ends = '\s'
    r = REHandler.SplitParagraph(s,keyword)
    print('-'*40)
    print(r)
    

    print('!'*40)
    
    keyword = 'class'
    s = 'class Response(): def Unknown(): pass \n'
    rests = '\w'
    ends = '\s'
    r = REHandler.SplitParagraph(s,keyword)
    print('-'*40)
    print(r)
    

    print('!'*40)
    
    keyword = 'class'
    s = 'class Response(): def Unknown(): pass \nclass Animal(): def Dog(): pass'
    rests = '\w'
    ends = '\s'
    r = REHandler.SplitParagraph(s,keyword)
    print('-'*40)
    print(r)
    
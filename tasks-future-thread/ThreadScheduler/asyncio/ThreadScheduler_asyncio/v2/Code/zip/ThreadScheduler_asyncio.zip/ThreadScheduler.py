"""
Edition:
    2th Edition
    
What's new?
    1. Wrap the code of 1th edition into functions and classes.
    2. Append *argv **kwargv in some function. The purpose is mainly to increase flexibilities.
    
Purpose:
    The purpose of this code is: 
        1. try to get the coroutine of main() ,then 
        2. do the following task and print the task and its result (if it is not cancelled.).
            2.1. try to get task of 0th of process whose process name is 'msedge.exe'. See the following statements: 
                processName = 'msedge.exe'
                procs = OSProcessHandler.Psutil.GetProcesses(processName)
                handler1 = loop.create_task(set_after(fut, 2, get_pid(procs[0]) ) )
            Here, the task is scheduled to perform after 2 seconds. See the following statement: 
                handler1 = loop.create_task(set_after(fut, 2, get_pid(procs[0]) ) 
            While, the task is cancelled after 3 seconds (if it is not executed). See the following statements: 
                thread1 = threading.Timer(3,cancel_task,[handler1],None)
                thread1.start()
            
Additional references:
    1. For HOW to use these modules (such as psutil, asyncio, threading etc),see my notes on repo on GitHub. (NOT written yet, ready to write)
    2. For HOW to get the current running loop and create the loop in different environment (such as IDE or Python interpreter), 
        see the Jean Monet's reply on the stackoverflow (which I also place it on the following code).
        https://stackoverflow.com/questions/55409641/asyncio-run-cannot-be-called-from-a-running-event-loop-when-using-jupyter-no 

Code on GitHub:
    The code is also available at repo Utility on GitHub.        
"""

import asyncio
from OSProcessHandler import OSProcessHandler

"""
Intro:
    Sleep for execution_delayed_seconds second then get pid of the process.
Parameter:
    1. fut: Future object.
    2. delay: sleep delay seconds.
    3. value: The value that result of fut will be set to.
Returned Value:
    Returns a int.
    Indicates pid of process 
    return process.pid.
NOTICE:
    NOTICE that it has no check for input values.
"""        
async def get_pid(process,execution_delayed_seconds:(int|float) = 1):
    # sleep for execution_delayed_seconds seconds.
    await asyncio.sleep(execution_delayed_seconds)
    # return pid of process.
    return process.pid

"""
Intro:
    Set the result of the Future object fut as value.
Parameter:
    1. fut: Future object.
    2. delay: sleep delay seconds.
    3. value: The value that result of fut will be set to.
Returned Value:
    None
NOTICE:
    NOTICE that it has no check for input values.
"""
async def set_after(fut, delay, value):
    # Sleep for *delay* seconds.
    await asyncio.sleep(delay)
    # Set *value* as a result of *fut* Future.
    fut.set_result(value)

"""
Intro:
    Cancel the task.
Parameter:
    1. task: task
    2. *argv: a list of arguments.
    3. **kwargv: a dict of arguments.
Returned Value:
    None
"""   
def cancel_task(task,*argv,**kwargv):
    print("cancel_task:")
    # cancel the task
    task.cancel()

"""
Intro:
    Print infos about t.
Parameter:
    1. t: info
Returned Value:
    None
"""
def print_info(t):
    print(t)
    print(type(t))
    print(dir(t))
    
"""
Intro:
    Print task and its result (returned by result() method).
Parameter:
    1. t: task
Returned Value:
    None
"""
def print_task(t):
    print("t:")
    print_info(t)
    print("t.result():")
    print_info(t.result())

"""
Intro:
    Print task and its result (returned by result() method).
Parameter:
    1. callback: callback as function.
    2. *argv: a list of arguments.
    3. **kwargv: a dict of arguments.
Returned Value:
    The return of method call callback(argv,kwargv).
"""
async def execute_task(callback,*argv,**kwargv):
    return callback(argv,kwargv)

"""
A class as wrapper that schedules task, or handles the scheduled task, or handles threading (Threading object in threading module) etc.
"""
class ThreadHandler():
    """
    A class as wrapper that schedules task, or handles the scheduled task.
    """
    class ThreadScheduler():
        """
        Intro:
            Get the current running loop.
            If either it does not exist or it is not running anymore, create a new loop.
            For more techinical details, see the following comments.
        Parameter:
            1. executed_callbacks: Always should be a list with two elems. If it is not so, an Exception is raised. 
                0th elem refers callback that will be callback first 
                    with [executed_args] and {} (i.e. empty set).
                1th elem refers callback that will be callback second 
                    with [execution_delayed_seconds] and {}.
                    
             2. executed_args: Always should be a list. A list of arguments.
                 
             3. executed_seconds: Always should be a int or float which is greater than 0. If it is not so, an Exception is raised. 
                 Refers that it will schedule the task to execute after executed_seconds seconds (if NOT cancelled.)
             
             4. execution_delayed_seconds: Always should be a int or float which is greater than 0. If it is not so, an Exception is raised.
                 Refers that it will sleep execution_delayed_seconds seconds and actually perform the context (if the task is executed.). It uses the method await asyncio.sleep(execution_delayed_seconds) to sleep.

             
             5. cancelled_seconds: Always should be a int or float which is greater than 0. If it is not so, an Exception is raised.
                 Refers the timeout of scheduled task. 
                 Refers that the task will be cancelled after cancelled_seconds seconds.
                 
        NOTICE:
            NOTICE that 
            1. the task will not be executed after it has been cancelled.
            2. it will also not perform context if the task has NOT been executed.
            3. it will NOT cancel the task if it has been executed.
            4. it will cancel the task iff the the task is NOT executed after timeout (which is set in the variable execution_delayed_seconds).

        Procedure:
            Procedure about task execution:
                Initialize variables -> 
                Schedule the task -> 
                Waiting for timeout ->
                Case 1:
                    If it is pending (NOT be executed) -> 
                        cancel it -> 
                        end
                NOTICE:
                    NOTICE that
                    1. When executed_seconds >= cancelled_seconds, the Case 1 will usually occur.
                        Ideally, it should always occur. 
                        However, I use asyncio.wait method which is NOT thread-safe. 
                        I can NOT ensure that there is a small bias or not.
                    2. In this case, the task is NOT done. (since it has been cancelled.)
                        Thus, this method call will NEVER return or will always return None.
                        For more details, see the NOTICE section after Returned Value section.
                        
                Case 2:
                   Otherwise (i.e. if it is executed) -> 
                   sleep execution_delayed_seconds -> 
                   actually perform its context ->
                   return resultant (returned value of the asyncio function of execute_task, here) ->
                   the task is done then perform the callback of done_callback which is pass in LoopHandler.GetRunningLoop method call (Since the task is done, task in the statement task.add_done_callback(done_callback) will be executed) ->
                   end 
                NOTICE:
                    NOTICE that 
                    1. When executed_seconds >= cancelled_seconds, the Case 1 will usually occur.
                        Ideally, it should always occur. 
                        The above description in NOTICE section fully describes the reason why it is.
                    2. In this case, the task usually is done. 
                        Thus, it usually returns the returned value in callback of executed_task iff the task is done. 
                        For more details, see the NOTICE section after Returned Value section.
                
       Returned Value:
            Return either one of these:
                None ,or the returned value in callback of executed_task iff the task is done. 
                For more details, see the NOTICE section after Returned Value section.                
        NOTICE:
            This method call will return the returned value in callback of executed_task iff the task is done. 
            Otherwise, it will NEVER return or will always return None.
        Variables in this method:
            I will list some variables which scope is in this method then describe what it refers.
            1. loop:
                In the statement:
                    loop = asyncio.get_running_loop()
                What it refers:
                    The current running loop.
                    
           2. fut:
               In the statement:
                   fut = loop.create_future()
               What it refers:
                   The Future object.
                   
           3. handler1:
               In the statement:
                   handler1 = loop.create_task(set_after(fut, executed_seconds, await execute_task( executed_callbacks[1] ,[execution_delayed_seconds] , {} ) ) )
               What it refers:
                   The Task object.
                   It schedules that the task executed_callback[1] will be executed.
                   
           4. done:
               In the statement:
                   (done,pending) = await asyncio.wait([handler1],timeout=cancelled_seconds)
               What it refers:
                   Among the tasks [handler1], which tasks are done (here, done refers that has response within timeout as cancelled_seconds seconds).
                   
           5. done:
               In the statement:
                   (done,pending) = await asyncio.wait([handler1],timeout=cancelled_seconds)
               What it refers:
                   Among the tasks [handler1], which tasks are pending (i.e. NOT done).
            NOTICE: 
                union of done and pending is equivalent to [handler1].
        """
        @staticmethod
        async def Execute(
                executed_callbacks : list = list() ,
                executed_args : (list| None) = list() ,
                executed_seconds:(int|float) = 1 ,
                execution_delayed_seconds:(int|float) = 1 ,
                cancelled_seconds:(int|float) = 1 
            ):
                if not isinstance(executed_callbacks, (list)):
                    raise Exception("The executed_callbacks must be a list with exactly two elems.")
                if len(executed_callbacks) != 2:
                    raise Exception("The executed_callbacks must be a list with exactly two elems.")
                    
                if not isinstance(executed_seconds, (int,float)):
                    raise Exception("The executed_seconds must be a int or float which is greater than 0.")
                if executed_seconds <= 0:
                    raise Exception("The executed_seconds must be a int or float which is greater than 0.")
                    
                if not isinstance(execution_delayed_seconds, (int,float)):
                    raise Exception("The execution_delayed_seconds must be a int or float which is greater than 0.")
                if execution_delayed_seconds <= 0:
                    raise Exception("The execution_delayed_seconds must be a int or float which is greater than 0.")
                    
                if not isinstance(execution_delayed_seconds, (int,float)):
                    raise Exception("The execution_delayed_seconds must be a int or float which is greater than 0.")
                if execution_delayed_seconds <= 0:
                    raise Exception("The execution_delayed_seconds must be a int or float which is greater than 0.")
                    
                try:
                    retVal = execute_task(executed_callbacks[0], [executed_args], {} )
                    
                    # Get the running loop with asyncio module.
                    loop = asyncio.get_running_loop()
                    
                    # Create a Future object.
                    fut = loop.create_future()
                    # Create a Task object which: 
                    # 1. the callback is executed (if it is not cancelled).
                    # 2. when executed, delay for executed_seconds seconds, then set the value of fut as executed_callbacks[1]([execution_delayed_seconds],{}).
                    handler1 = loop.create_task(set_after(fut, executed_seconds, await execute_task( executed_callbacks[1] ,[execution_delayed_seconds] , {} ) ) )
                    
                    # wait the cancelled_seconds with asyncio module.
                    (done,pending) = await asyncio.wait([handler1],timeout=cancelled_seconds)
                    print(f"done:{done},pending:{pending}.")
                    
                    # if asyncio.Task object handler1 is not complete in timeout (which is stored in cancelled_seconds variable.)
                    if handler1 in pending:
                        # cancel the task.
                        cancel_task(handler1, [] , {})
                        
                    # await fut and return result into variable result (if the task handler1 is not cancelled).
                    result = await fut
                    # return the result.
                    return result
                except Exception as ex:
                    print("Error in method Execute.")
                    print("ex:" %(str(ex)))
                    return None

"""
A class that handles the class asyncio.windows_events._WindowsSelectorEventLoop.
"""
class LoopHandler():
    """
    Intro:
        Get the current running loop.
        If either it does not exist or it is not running anymore, create a new loop.
        For more techinical details, see the following comments.
    Parameter:
        1. done_callback: The callback that executed once after the speficied task is completely done. (NOT including the case that it is cancelled.)
    Returned Value:
        None
    """
    @staticmethod
    def GetRunningLoop(done_callback):
        # We have to do troublesome condition check due to different ways to handle running loop in different IDE or Python interpreter etc.
        # The code is modified from the Jean Monet's reply on the stackoverflow.
        # https://stackoverflow.com/questions/55409641/asyncio-run-cannot-be-called-from-a-running-event-loop-when-using-jupyter-no
        # For more details, see my notes at GitHub. (NOT written yet, but ready to write.)
        try:
            # Try to get current running loop with asyncio module. 
            loop = asyncio.get_running_loop()
        except RuntimeError:  # 'RuntimeError: There is no current event loop...'
            loop = None
        
        # Check loop is None (such as When there are no current running loop, thus raise RuntimeError.) , and 
        # the loop is running.
        if loop and loop.is_running():
            # It occurs such as when one of these conditions are NOT satisfied: 
            # 1. Python ≥ 3.7, and 
            # 2. IPython < 7.0
            print('Async event loop already running. Adding coroutine to the event loop.')
            try:
                # Create a Task object with coroutine object -- main().
                task = loop.create_task(main())
                # Add a callback "lambda t: print_task(t)" to task when it is completed done. (NOT including the case that it is cancelled.)
                task.add_done_callback(
                    done_callback
                )
            except TimeoutError as ex:
                print("TimeoutError:")
                print(ex)
                
        else:
            # Otherwise,
            # It occurs such as when all of these conditions are satisfied: 
            # 1. Python ≥ 3.7, and 
            # 2. IPython < 7.0
            print('Starting new event loop')
            # Just start a new event loop.
            result = asyncio.run(main())
"""
main function
"""  
async def main():
    try:
        await ThreadHandler.ThreadScheduler.Execute(
            executed_callbacks = [ OSProcessHandler.Psutil.GetProcesses , get_pid ],
            executed_args='msedge.exe',
            executed_seconds=2,
            execution_delayed_seconds=2,
            cancelled_seconds=1
        )    
    except RuntimeWarning as ex:
        print(ex)
"""
Driver code
"""
if __name__ == '__main__':
    LoopHandler.GetRunningLoop(lambda t:print_task(t))
    